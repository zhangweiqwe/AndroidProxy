ALTER TABLE Preset ADD Starred INTEGER DEFAULT 0;
ALTER TABLE Preset ADD Resolution TEXT;
DELETE FROM Preset WHERE Name = 'default';